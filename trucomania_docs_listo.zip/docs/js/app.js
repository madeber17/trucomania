function crearMesa(){alert("Mesa privada creada. Código: TRUCO123");}
function entrarMesa(){const c=prompt("Ingresá el código de la mesa:");if(c)alert("Entrando a la mesa: "+c);}